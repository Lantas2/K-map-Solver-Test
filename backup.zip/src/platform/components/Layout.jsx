import { SITE_CONFIG } from "../siteConfig";
import { Button } from "./UI";

function InternalLink({ href, children, onNavigate, className = "" }) {
  return (
    <a
      className={className}
      href={href}
      onClick={(event) => {
        event.preventDefault();
        onNavigate(href);
      }}
    >
      {children}
    </a>
  );
}

export function Navbar({ onNavigate }) {
  return (
    <header className="cit-navbar">
      <div className="cit-nav-inner">
        <InternalLink className="cit-brand" href="/" onNavigate={onNavigate}>
          <span className="cit-brand-mark">{SITE_CONFIG.mark}</span>
          <span className="cit-brand-copy">
            <strong>{SITE_CONFIG.name}</strong>
            <small>{SITE_CONFIG.subtitle}</small>
          </span>
        </InternalLink>

        <nav className="cit-nav-links" aria-label="CITools navigation">
          <a href={SITE_CONFIG.githubUrl} target="_blank" rel="noreferrer">GitHub</a>
          <a href={SITE_CONFIG.linkedinUrl} target="_blank" rel="noreferrer">LinkedIn</a>
          <a href="#creator">Pembuat</a>
          <a href="#university">Asal Universitas</a>
          <InternalLink href="/about" onNavigate={onNavigate}>About</InternalLink>
        </nav>
      </div>
    </header>
  );
}

export function Footer({ onNavigate }) {
  return (
    <footer className="cit-footer">
      <div className="cit-footer-brand">
        <span className="cit-brand-mark">CIT</span>
        <div>
          <strong>CITools</strong>
          <p>Engineering learning tools for digital education.</p>
        </div>
      </div>
      <div className="cit-footer-links">
        <InternalLink href="/digital-electronics" onNavigate={onNavigate}>Elektronika Digital</InternalLink>
        <InternalLink href="/about" onNavigate={onNavigate}>Tentang Project</InternalLink>
        <a href={SITE_CONFIG.githubUrl} target="_blank" rel="noreferrer">GitHub</a>
      </div>
      <p className="cit-copyright">© 2026 {SITE_CONFIG.creator}. Built as an academic technology portfolio.</p>
    </footer>
  );
}

export function Layout({ children, onNavigate }) {
  return (
    <div className="citools-site">
      <div className="cit-background-grid" aria-hidden="true" />
      <Navbar onNavigate={onNavigate} />
      <main className="cit-main">{children}</main>
      <Footer onNavigate={onNavigate} />
    </div>
  );
}

export function ToolRouteHeader({ title, onNavigate }) {
  return (
    <div className="cit-toolroute-bar">
      <button type="button" onClick={() => onNavigate("/digital-electronics")}>
        <span>CIT</span>
        Elektronika Digital
      </button>
      <div>
        <small>Active Tool</small>
        <strong>{title}</strong>
      </div>
      <Button href="/" variant="ghost" onNavigate={onNavigate}>Home</Button>
    </div>
  );
}
