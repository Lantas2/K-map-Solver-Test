import { inputPortsForType, outputPortsForType } from "../registry/componentRegistry";

export { inputPortsForType, outputPortsForType };

export function evaluateComponent(type, inputMap = {}, properties = {}) {
  const a = Boolean(inputMap.inA ?? inputMap.a ?? inputMap.d0);
  const b = Boolean(inputMap.inB ?? inputMap.b ?? inputMap.d1);

  switch (type) {
    case "INPUT":
    case "CONSTANT": return { out: Boolean(properties.value) };
    case "OUTPUT":
    case "PROBE":
    case "BUFFER": return { out: a };
    case "AND": return { out: a && b };
    case "OR": return { out: a || b };
    case "NOT": return { out: !a };
    case "XOR": return { out: a !== b };
    case "NAND": return { out: !(a && b) };
    case "NOR": return { out: !(a || b) };
    case "XNOR": return { out: a === b };
    case "HALF_ADDER": return { sum: a !== b, carry: a && b };
    case "FULL_ADDER": {
      const cin = Boolean(inputMap.cin);
      return { sum: a !== b !== cin, cout: (a && b) || (a && cin) || (b && cin) };
    }
    case "MUX2": return { out: inputMap.sel ? Boolean(inputMap.d1) : Boolean(inputMap.d0) };
    case "DECODER2": {
      const index = Number(a) + Number(b) * 2;
      return { y0: index === 0, y1: index === 1, y2: index === 2, y3: index === 3 };
    }
    default: {
      const output = outputPortsForType(type)[0] ?? "out";
      return { [output]: false };
    }
  }
}

export function truthTableForType(type) {
  const ports = inputPortsForType(type);
  if (!ports.length || ports.length > 3) return [];
  const rowCount = 2 ** ports.length;
  return Array.from({ length: rowCount }, (_, index) => {
    const inputs = Object.fromEntries(ports.map((port, offset) => [port, Boolean((index >> (ports.length - offset - 1)) & 1)]));
    return { inputs, outputs: evaluateComponent(type, inputs) };
  });
}
