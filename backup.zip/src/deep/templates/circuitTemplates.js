function node(id, type, label, x, y, properties = {}) {
  return { id, type, label, x, y, properties };
}
function edge(id, source, target, targetPort, sourcePort = "out") {
  return { id, source, sourcePort, target, targetPort };
}

export const CIRCUIT_TEMPLATES = [
  {
    id: "half-adder",
    name: "Half Adder",
    category: "Arithmetic",
    description: "Gate-level SUM and CARRY from A and B.",
    nodes: [
      node("ha-a", "INPUT", "A", 74, 160, { value: true }),
      node("ha-b", "INPUT", "B", 74, 340, { value: false }),
      node("ha-xor", "XOR", "SUM XOR", 390, 160),
      node("ha-and", "AND", "CARRY AND", 390, 340),
      node("ha-sum", "OUTPUT", "SUM", 724, 160),
      node("ha-carry", "OUTPUT", "CARRY", 724, 340),
    ],
    edges: [
      edge("ha-e1", "ha-a", "ha-xor", "inA"), edge("ha-e2", "ha-b", "ha-xor", "inB"),
      edge("ha-e3", "ha-a", "ha-and", "inA"), edge("ha-e4", "ha-b", "ha-and", "inB"),
      edge("ha-e5", "ha-xor", "ha-sum", "inA"), edge("ha-e6", "ha-and", "ha-carry", "inA"),
    ],
  },
  {
    id: "full-adder",
    name: "Full Adder",
    category: "Arithmetic",
    description: "Single functional block with carry-in and carry-out.",
    nodes: [
      node("fa-a", "INPUT", "A", 70, 118, { value: true }), node("fa-b", "INPUT", "B", 70, 267, { value: false }),
      node("fa-cin", "INPUT", "CIN", 70, 416, { value: true }), node("fa-core", "FULL_ADDER", "FULL ADDER", 390, 252),
      node("fa-sum", "OUTPUT", "SUM", 736, 196), node("fa-cout", "OUTPUT", "COUT", 736, 352),
    ],
    edges: [
      edge("fa-e1", "fa-a", "fa-core", "a"), edge("fa-e2", "fa-b", "fa-core", "b"), edge("fa-e3", "fa-cin", "fa-core", "cin"),
      edge("fa-e4", "fa-core", "fa-sum", "inA", "sum"), edge("fa-e5", "fa-core", "fa-cout", "inA", "cout"),
    ],
  },
  {
    id: "mux-2to1",
    name: "2-to-1 MUX",
    category: "Plexers",
    description: "Select one of two data lines.",
    nodes: [
      node("mux-d0", "INPUT", "D0", 72, 122, { value: false }), node("mux-d1", "INPUT", "D1", 72, 282, { value: true }),
      node("mux-sel", "INPUT", "SEL", 72, 442, { value: true }), node("mux-core", "MUX2", "MUX 2:1", 412, 268),
      node("mux-out", "OUTPUT", "OUT", 748, 268),
    ],
    edges: [edge("mx-e1", "mux-d0", "mux-core", "d0"), edge("mx-e2", "mux-d1", "mux-core", "d1"), edge("mx-e3", "mux-sel", "mux-core", "sel"), edge("mx-e4", "mux-core", "mux-out", "inA")],
  },
  {
    id: "decoder-2to4",
    name: "Decoder 2-to-4",
    category: "Plexers",
    description: "One-hot decoding from a 2-bit selection.",
    nodes: [
      node("dec-a", "INPUT", "A", 65, 215, { value: true }), node("dec-b", "INPUT", "B", 65, 360, { value: false }),
      node("dec-core", "DECODER2", "DECODER", 360, 276),
      node("dec-y0", "OUTPUT", "Y0", 728, 118), node("dec-y1", "OUTPUT", "Y1", 728, 240),
      node("dec-y2", "OUTPUT", "Y2", 728, 362), node("dec-y3", "OUTPUT", "Y3", 728, 484),
    ],
    edges: [
      edge("dc-e1", "dec-a", "dec-core", "a"), edge("dc-e2", "dec-b", "dec-core", "b"),
      edge("dc-e3", "dec-core", "dec-y0", "inA", "y0"), edge("dc-e4", "dec-core", "dec-y1", "inA", "y1"),
      edge("dc-e5", "dec-core", "dec-y2", "inA", "y2"), edge("dc-e6", "dec-core", "dec-y3", "inA", "y3"),
    ],
  },
];

export function cloneTemplate(id) {
  const template = CIRCUIT_TEMPLATES.find((item) => item.id === id) ?? CIRCUIT_TEMPLATES[0];
  return {
    ...template,
    nodes: template.nodes.map((item) => ({ ...item, properties: { ...item.properties } })),
    edges: template.edges.map((item) => ({ ...item })),
  };
}
