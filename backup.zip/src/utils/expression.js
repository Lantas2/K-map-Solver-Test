export function generateExpression() {
  return "";
}