export function generateGroups() {
  return [];
}