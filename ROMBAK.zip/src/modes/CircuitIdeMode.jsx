import { useEffect, useMemo, useRef, useState } from "react";
import { evaluateCircuit } from "../deep/engine/evaluateCircuit";
import { inputPortsForType } from "../deep/engine/gateLogic";

const COMPONENT_GROUPS = [
  { title: "Signals", types: ["INPUT", "OUTPUT"] },
  { title: "Logic Gates", types: ["AND", "OR", "NOT", "XOR", "NAND", "NOR", "XNOR"] },
];

const SAMPLE_NODES = [
  { id: "n1", type: "INPUT", label: "A", x: 80, y: 118, value: true },
  { id: "n2", type: "INPUT", label: "B", x: 80, y: 302, value: false },
  { id: "n3", type: "XOR", label: "XOR 1", x: 386, y: 115, value: false },
  { id: "n4", type: "AND", label: "AND 1", x: 386, y: 300, value: false },
  { id: "n5", type: "OUTPUT", label: "SUM", x: 708, y: 115, value: false },
  { id: "n6", type: "OUTPUT", label: "CARRY", x: 708, y: 300, value: false },
];

const SAMPLE_EDGES = [
  { id: "e1", source: "n1", target: "n3", targetPort: "inA" },
  { id: "e2", source: "n2", target: "n3", targetPort: "inB" },
  { id: "e3", source: "n1", target: "n4", targetPort: "inA" },
  { id: "e4", source: "n2", target: "n4", targetPort: "inB" },
  { id: "e5", source: "n3", target: "n5", targetPort: "inA" },
  { id: "e6", source: "n4", target: "n6", targetPort: "inA" },
];

const NODE_W = 132;
const NODE_H = 76;
const BOARD_W = 1080;
const BOARD_H = 660;

function cloneSample() {
  return {
    nodes: SAMPLE_NODES.map((node) => ({ ...node })),
    edges: SAMPLE_EDGES.map((edge) => ({ ...edge })),
  };
}

function createId(prefix) {
  return `${prefix}-${Date.now()}-${Math.random().toString(16).slice(2, 7)}`;
}

function nextLabel(type, nodes) {
  if (type === "INPUT") {
    const labels = ["A", "B", "C", "D", "E", "F"];
    return labels[nodes.filter((node) => node.type === "INPUT").length] ?? `IN ${nodes.length + 1}`;
  }
  if (type === "OUTPUT") return `OUT ${nodes.filter((node) => node.type === "OUTPUT").length + 1}`;
  return `${type} ${nodes.filter((node) => node.type === type).length + 1}`;
}

function outputPoint(node) {
  return { x: node.x + NODE_W, y: node.y + NODE_H / 2 };
}

function inputPoint(node, port) {
  const ports = inputPortsForType(node.type);
  const y = ports.length === 1 ? node.y + NODE_H / 2 : node.y + (port === "inA" ? 25 : 53);
  return { x: node.x, y };
}

function wirePath(source, target, targetPort) {
  const start = outputPoint(source);
  const end = inputPoint(target, targetPort);
  const control = Math.max(48, Math.abs(end.x - start.x) * 0.48);
  return `M ${start.x} ${start.y} C ${start.x + control} ${start.y}, ${end.x - control} ${end.y}, ${end.x} ${end.y}`;
}

function downloadProject(nodes, edges) {
  const payload = JSON.stringify({ format: "circuit-ide-v1", nodes, edges }, null, 2);
  const url = URL.createObjectURL(new Blob([payload], { type: "application/json" }));
  const anchor = document.createElement("a");
  anchor.href = url;
  anchor.download = "circuit-project.json";
  anchor.click();
  URL.revokeObjectURL(url);
}

export default function CircuitIdeMode() {
  const sample = useMemo(() => cloneSample(), []);
  const [nodes, setNodes] = useState(sample.nodes);
  const [edges, setEdges] = useState(sample.edges);
  const [selectedNodeId, setSelectedNodeId] = useState("n3");
  const [selectedEdgeId, setSelectedEdgeId] = useState(null);
  const [connectionSource, setConnectionSource] = useState(null);
  const [drag, setDrag] = useState(null);
  const [zoom, setZoom] = useState(100);
  const [notice, setNotice] = useState("Klik port output lalu port input untuk membuat wire.");
  const boardRef = useRef(null);
  const fileInputRef = useRef(null);

  const simulation = useMemo(() => evaluateCircuit(nodes, edges), [nodes, edges]);
  const selectedNode = nodes.find((node) => node.id === selectedNodeId) ?? null;
  const selectedEdge = edges.find((edge) => edge.id === selectedEdgeId) ?? null;
  const inputs = nodes.filter((node) => node.type === "INPUT");
  const outputs = nodes.filter((node) => node.type === "OUTPUT");

  useEffect(() => {
    if (!drag) return undefined;

    const onMove = (event) => {
      const rect = boardRef.current?.getBoundingClientRect();
      if (!rect) return;
      const scale = zoom / 100;
      const x = Math.max(18, Math.min(BOARD_W - NODE_W - 18, (event.clientX - rect.left) / scale - drag.offsetX));
      const y = Math.max(52, Math.min(BOARD_H - NODE_H - 18, (event.clientY - rect.top) / scale - drag.offsetY));
      setNodes((current) => current.map((node) => node.id === drag.id ? { ...node, x, y } : node));
    };

    const onUp = () => setDrag(null);
    window.addEventListener("pointermove", onMove);
    window.addEventListener("pointerup", onUp);
    return () => {
      window.removeEventListener("pointermove", onMove);
      window.removeEventListener("pointerup", onUp);
    };
  }, [drag, zoom]);

  function addNode(type, position) {
    const count = nodes.length;
    const node = {
      id: createId("node"),
      type,
      label: nextLabel(type, nodes),
      value: false,
      x: position?.x ?? 160 + ((count * 36) % 460),
      y: position?.y ?? 100 + ((count * 58) % 420),
    };
    setNodes((current) => [...current, node]);
    setSelectedNodeId(node.id);
    setSelectedEdgeId(null);
    setNotice(`${node.label} ditambahkan ke canvas.`);
  }

  function beginDrag(event, node) {
    if (event.target.closest(".node-port") || event.target.closest(".node-toggle")) return;
    const rect = boardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const scale = zoom / 100;
    setDrag({
      id: node.id,
      offsetX: (event.clientX - rect.left) / scale - node.x,
      offsetY: (event.clientY - rect.top) / scale - node.y,
    });
    setSelectedNodeId(node.id);
    setSelectedEdgeId(null);
  }

  function startConnection(event, nodeId) {
    event.stopPropagation();
    setConnectionSource(nodeId);
    setSelectedNodeId(nodeId);
    setSelectedEdgeId(null);
    const source = nodes.find((node) => node.id === nodeId);
    setNotice(`Wire dari ${source?.label ?? "node"}: pilih port input tujuan.`);
  }

  function completeConnection(event, targetId, targetPort) {
    event.stopPropagation();
    if (!connectionSource) {
      setNotice("Pilih port output sumber terlebih dahulu.");
      return;
    }
    if (connectionSource === targetId) {
      setNotice("Node tidak dapat dihubungkan ke dirinya sendiri.");
      return;
    }
    const newEdge = { id: createId("wire"), source: connectionSource, target: targetId, targetPort };
    setEdges((current) => [
      ...current.filter((edge) => !(edge.target === targetId && edge.targetPort === targetPort)),
      newEdge,
    ]);
    const target = nodes.find((node) => node.id === targetId);
    setConnectionSource(null);
    setNotice(`Wire tersambung ke ${target?.label ?? "node"}. Sinyal dihitung realtime.`);
  }

  function toggleInput(nodeId) {
    setNodes((current) => current.map((node) => node.id === nodeId ? { ...node, value: !node.value } : node));
  }

  function removeSelection() {
    if (selectedEdgeId) {
      setEdges((current) => current.filter((edge) => edge.id !== selectedEdgeId));
      setSelectedEdgeId(null);
      setNotice("Wire dihapus.");
      return;
    }
    if (!selectedNodeId) return;
    const node = nodes.find((item) => item.id === selectedNodeId);
    setNodes((current) => current.filter((item) => item.id !== selectedNodeId));
    setEdges((current) => current.filter((edge) => edge.source !== selectedNodeId && edge.target !== selectedNodeId));
    setSelectedNodeId(null);
    setNotice(`${node?.label ?? "Node"} dihapus.`);
  }

  function loadSample() {
    const next = cloneSample();
    setNodes(next.nodes);
    setEdges(next.edges);
    setSelectedNodeId("n3");
    setSelectedEdgeId(null);
    setConnectionSource(null);
    setNotice("Sample Half Adder dimuat.");
  }

  function clearCanvas() {
    setNodes([]);
    setEdges([]);
    setSelectedNodeId(null);
    setSelectedEdgeId(null);
    setConnectionSource(null);
    setNotice("Canvas kosong. Tambahkan komponen dari Library.");
  }

  function loadProject(event) {
    const file = event.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      try {
        const parsed = JSON.parse(String(reader.result));
        if (!Array.isArray(parsed.nodes) || !Array.isArray(parsed.edges)) throw new Error("Invalid circuit file");
        setNodes(parsed.nodes);
        setEdges(parsed.edges);
        setSelectedNodeId(parsed.nodes[0]?.id ?? null);
        setSelectedEdgeId(null);
        setConnectionSource(null);
        setNotice("Project JSON berhasil dimuat.");
      } catch {
        setNotice("File JSON tidak valid untuk Circuit IDE.");
      }
    };
    reader.readAsText(file);
    event.target.value = "";
  }

  function onDropComponent(event) {
    event.preventDefault();
    const type = event.dataTransfer.getData("application/circuit-component");
    if (!type) return;
    const rect = boardRef.current?.getBoundingClientRect();
    if (!rect) return;
    const scale = zoom / 100;
    addNode(type, {
      x: Math.max(18, Math.min(BOARD_W - NODE_W - 18, (event.clientX - rect.left) / scale - NODE_W / 2)),
      y: Math.max(52, Math.min(BOARD_H - NODE_H - 18, (event.clientY - rect.top) / scale - NODE_H / 2)),
    });
  }

  return (
    <section className="circuit-ide phase-two" aria-label="Circuit IDE interactive workspace">
      <header className="deep-toolbar">
        <div className="deep-project">
          <span className="deep-status-dot active" />
          <div>
            <small>Advanced Circuit Studio</small>
            <strong>interactive-circuit.logic</strong>
          </div>
        </div>
        <div className="deep-toolbar-actions">
          <button type="button" className="deep-action" onClick={clearCanvas}>New</button>
          <button type="button" className="deep-action" onClick={loadSample}>Load Sample</button>
          <button type="button" className="deep-action" onClick={() => downloadProject(nodes, edges)}>Save JSON</button>
          <button type="button" className="deep-action" onClick={() => fileInputRef.current?.click()}>Load JSON</button>
          <input ref={fileInputRef} type="file" accept="application/json" hidden onChange={loadProject} />
          <button type="button" className="deep-action danger" disabled={!selectedNodeId && !selectedEdgeId} onClick={removeSelection}>Delete</button>
        </div>
      </header>

      <div className="deep-studio-grid">
        <aside className="deep-library" aria-label="Circuit component library">
          <div className="deep-panel-title"><span>Library</span><b>Components</b></div>
          <p className="library-tip">Klik atau drag komponen ke canvas.</p>
          {COMPONENT_GROUPS.map((group) => (
            <div className="deep-library-group" key={group.title}>
              <h3>{group.title}</h3>
              <div className="deep-library-items">
                {group.types.map((type) => (
                  <button
                    type="button"
                    draggable
                    key={type}
                    className="deep-component available"
                    onClick={() => addNode(type)}
                    onDragStart={(event) => event.dataTransfer.setData("application/circuit-component", type)}
                  >
                    <i>{type.slice(0, 2)}</i>{type}
                  </button>
                ))}
              </div>
            </div>
          ))}
          <div className="connection-help">
            <b>Wiring</b>
            <span>1. Klik pin kanan output</span>
            <span>2. Klik pin kiri input</span>
            <span>3. Klik input switch untuk ON/OFF</span>
          </div>
        </aside>

        <section className="deep-canvas-panel">
          <div className="deep-canvas-toolbar">
            <div><strong>Interactive Canvas</strong><span>{notice}</span></div>
            <div className="deep-canvas-chipset">
              <button type="button" onClick={() => setZoom((value) => Math.max(70, value - 10))}>−</button>
              <span>{zoom}%</span>
              <button type="button" onClick={() => setZoom((value) => Math.min(140, value + 10))}>+</button>
              <span className="signal-on">Signal Live</span>
            </div>
          </div>
          <div className="deep-canvas-scroll">
            <div
              ref={boardRef}
              className="deep-canvas ide-board"
              style={{ transform: `scale(${zoom / 100})` }}
              onDragOver={(event) => event.preventDefault()}
              onDrop={onDropComponent}
              onClick={() => { setSelectedNodeId(null); setSelectedEdgeId(null); }}
            >
              <div className="deep-axis-label">Realtime propagation canvas • drop components here</div>
              <svg className="ide-wires" viewBox={`0 0 ${BOARD_W} ${BOARD_H}`} aria-label="Circuit wires">
                {simulation.evaluatedEdges.map((edge) => {
                  const source = nodes.find((node) => node.id === edge.source);
                  const target = nodes.find((node) => node.id === edge.target);
                  if (!source || !target) return null;
                  const path = wirePath(source, target, edge.targetPort);
                  return (
                    <g key={edge.id} className={`ide-wire ${edge.active ? "active" : ""} ${selectedEdgeId === edge.id ? "selected" : ""}`} onClick={(event) => { event.stopPropagation(); setSelectedEdgeId(edge.id); setSelectedNodeId(null); }}>
                      <path className="wire-hit" d={path} />
                      <path className="wire-line" d={path} />
                    </g>
                  );
                })}
              </svg>
              {nodes.map((node) => (
                <div
                  key={node.id}
                  className={`ide-node node-${node.type.toLowerCase()} ${selectedNodeId === node.id ? "selected" : ""} ${simulation.signalByNode[node.id] ? "active" : ""}`}
                  style={{ left: node.x, top: node.y }}
                  onPointerDown={(event) => beginDrag(event, node)}
                  onClick={(event) => { event.stopPropagation(); setSelectedNodeId(node.id); setSelectedEdgeId(null); }}
                >
                  {inputPortsForType(node.type).map((port) => (
                    <button key={port} type="button" className={`node-port input-port ${port}`} onClick={(event) => completeConnection(event, node.id, port)} title={`Connect ${port}`} />
                  ))}
                  <div className="node-header"><small>{node.type}</small><strong>{node.label}</strong></div>
                  {node.type === "INPUT" ? (
                    <button type="button" className={`node-toggle ${node.value ? "on" : ""}`} onClick={(event) => { event.stopPropagation(); toggleInput(node.id); }}>
                      {node.value ? "ON / 1" : "OFF / 0"}
                    </button>
                  ) : (
                    <em>{simulation.signalByNode[node.id] ? "1" : "0"}</em>
                  )}
                  {node.type !== "OUTPUT" && (
                    <button type="button" className={`node-port output-port ${connectionSource === node.id ? "connecting" : ""}`} onClick={(event) => startConnection(event, node.id)} title="Start wire" />
                  )}
                </div>
              ))}
            </div>
          </div>
          <div className="deep-debug-strip">
            <div className="debug-readout">
              <span>Binary monitor</span>
              <b>{inputs.map((node) => `${node.label}=${simulation.signalByNode[node.id] ? 1 : 0}`).join("  ") || "No input"} &nbsp;│&nbsp; {outputs.map((node) => `${node.label}=${simulation.signalByNode[node.id] ? 1 : 0}`).join("  ") || "No output"}</b>
            </div>
            <div className={`debug-readout ${simulation.warnings.length ? "warning" : "ok"}`}>
              <span>Circuit analyzer</span>
              <b>{simulation.warnings.length ? `${simulation.warnings.length} connection warning(s)` : "Circuit connected"}</b>
            </div>
          </div>
        </section>

        <aside className="deep-inspector" aria-label="Circuit inspector">
          <div className="deep-panel-title"><span>Inspector</span><b>{selectedEdge ? "Selected Wire" : "Selected Node"}</b></div>
          {selectedEdge ? (
            <div className="selected-node-card">
              <span>WIRE</span>
              <h3>{selectedEdge.source} → {selectedEdge.target}</h3>
              <div className="selected-signal"><small>Signal</small><strong className={simulation.signalByNode[selectedEdge.source] ? "active" : ""}>{simulation.signalByNode[selectedEdge.source] ? "HIGH / 1" : "LOW / 0"}</strong></div>
            </div>
          ) : selectedNode ? (
            <div className="selected-node-card">
              <span>{selectedNode.type}</span>
              <h3>{selectedNode.label}</h3>
              <div className="selected-signal"><small>Signal</small><strong className={simulation.signalByNode[selectedNode.id] ? "active" : ""}>{simulation.signalByNode[selectedNode.id] ? "HIGH / 1" : "LOW / 0"}</strong></div>
              <div className="inspector-position"><span>X {Math.round(selectedNode.x)}</span><span>Y {Math.round(selectedNode.y)}</span></div>
            </div>
          ) : (
            <div className="empty-inspector">Pilih node atau wire untuk melihat detail.</div>
          )}

          <div className="deep-panel-title analyzer-title"><span>Analyzer</span><b>Warnings</b></div>
          <div className="analyzer-list">
            {simulation.warnings.length ? simulation.warnings.slice(0, 7).map((warning) => <p key={warning}>{warning}</p>) : <p className="success">Tidak ada input kosong.</p>}
          </div>
          <div className="phase-note"><span>Phase 2</span><p>Drag, wire connection, realtime propagation, JSON save/load, zoom, delete, dan analyzer dasar sudah aktif.</p></div>
        </aside>
      </div>
    </section>
  );
}
