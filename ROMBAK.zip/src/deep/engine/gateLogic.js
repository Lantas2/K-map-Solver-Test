export const SUPPORTED_TYPES = ["INPUT", "OUTPUT", "AND", "OR", "NOT", "XOR", "NAND", "NOR", "XNOR"];

export function isGateType(type) {
  return !["INPUT", "OUTPUT"].includes(type);
}

export function inputPortsForType(type) {
  if (type === "INPUT") return [];
  if (type === "NOT" || type === "OUTPUT") return ["inA"];
  return ["inA", "inB"];
}

export function evaluateGate(type, inputs) {
  const a = Boolean(inputs[0]);
  const b = Boolean(inputs[1]);

  switch (type) {
    case "AND": return a && b;
    case "OR": return a || b;
    case "NOT": return !a;
    case "XOR": return a !== b;
    case "NAND": return !(a && b);
    case "NOR": return !(a || b);
    case "XNOR": return a === b;
    case "OUTPUT": return a;
    default: return false;
  }
}
