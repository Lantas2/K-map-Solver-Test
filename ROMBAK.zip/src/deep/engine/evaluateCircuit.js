import { evaluateGate, inputPortsForType } from "./gateLogic";

export function evaluateCircuit(nodes, edges) {
  const signalByNode = Object.fromEntries(nodes.map((node) => [node.id, node.type === "INPUT" ? Boolean(node.value) : false]));
  const maxPasses = Math.max(2, nodes.length + 2);

  for (let pass = 0; pass < maxPasses; pass += 1) {
    let changed = false;

    nodes.forEach((node) => {
      if (node.type === "INPUT") return;
      const ports = inputPortsForType(node.type);
      const values = ports.map((port) => {
        const edge = edges.find((item) => item.target === node.id && item.targetPort === port);
        return edge ? Boolean(signalByNode[edge.source]) : false;
      });
      const nextValue = evaluateGate(node.type, values);
      if (signalByNode[node.id] !== nextValue) {
        signalByNode[node.id] = nextValue;
        changed = true;
      }
    });

    if (!changed) break;
  }

  const evaluatedEdges = edges.map((edge) => ({ ...edge, active: Boolean(signalByNode[edge.source]) }));
  const warnings = [];

  nodes.forEach((node) => {
    inputPortsForType(node.type).forEach((port) => {
      if (!edges.some((edge) => edge.target === node.id && edge.targetPort === port)) {
        warnings.push(`${node.label}: ${port === "inA" ? "input A" : "input B"} belum tersambung`);
      }
    });
  });

  return { signalByNode, evaluatedEdges, warnings };
}
